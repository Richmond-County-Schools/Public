﻿cmd /c "chkdsk c: /r /f"
