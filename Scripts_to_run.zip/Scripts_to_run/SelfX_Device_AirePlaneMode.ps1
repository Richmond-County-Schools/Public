﻿Get-NetAdapter * | restart-netadapter
# Disable-NetAdapter *
# Enable-NetAdapter *

