Write-Host "Starting full profile cleanup..."

# -------------------------------
# 1. Log off all interactive users
# -------------------------------

Write-Host "Logging off active user sessions..."

$sessions = quser 2>$null | Select-Object -Skip 1

foreach ($session in $sessions) {
    $parts = ($session -replace '\s{2,}', ',').Split(',')
    $sessionId = $parts[2]

    if ($sessionId -match '^\d+$') {
        Write-Host "Logging off session ID $sessionId"
        logoff $sessionId /V
    }
}

Start-Sleep -Seconds 10

# -------------------------------
# 2. Delete all non-special profiles
# -------------------------------

Write-Host "Deleting all non-special user profiles..."

$profiles = Get-CimInstance Win32_UserProfile | Where-Object {
    $_.Special -eq $false
}

foreach ($userProfile in $profiles) {
    try {
        Write-Host "Deleting profile: $($userProfile.LocalPath)"
        $userProfile | Remove-CimInstance -ErrorAction Stop
    }
    catch {
        Write-Warning "Failed to delete $($userProfile.LocalPath): $_"
    }
}

Write-Host "Profile cleanup complete."