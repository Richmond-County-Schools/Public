<#
🟢 7. Reset Print Spooler & Clear Queue

In K-12 / EDU? This is mandatory.

Fix

Stop Spooler

Clear:

C:\Windows\System32\spool\PRINTERS

Restart Spooler

💡 Solves: “Printer stuck / won’t print / ghost jobs”
#>