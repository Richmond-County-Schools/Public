<#
🟡 13. Verify & Repair WMI

Advanced, but clutch for broken management clients.

Fix

Verify repository

Salvage or reset if needed

💡 Only include if logged + documented well
#>