<#
🟢 1. Restart Core Windows Services (Top Tier Fix)

These solve a shocking number of “my computer is broken” tickets.

Examples

Windows Update stuck

Software installs failing

Network weirdness

GPO not applying

Fix script ideas

Restart:

wuauserv

bits

cryptsvc

ccmexec (SCCM)

IntuneManagementExtension

Dnscache

LanmanWorkstation

💡 Label it:
“Restart Windows Management Services”
#>

$LogPath = "C:\ProgramData\SelfX\Logs"
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}
Start-Transcript -Path "$LogPath\<SCRIPTNAME>.log" -Append

$services = @(
    "wuauserv",
    "bits",
    "cryptsvc",
    "Dnscache",
    "LanmanWorkstation"
)

foreach ($svc in $services) {
    if (Get-Service -Name $svc -ErrorAction SilentlyContinue) {
        Restart-Service -Name $svc -Force -ErrorAction SilentlyContinue
    }
}

Stop-Transcript