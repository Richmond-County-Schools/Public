$LogPath = "C:\ProgramData\SelfX\Logs"
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}
Start-Transcript -Path "$LogPath\<SCRIPTNAME>.log" -Append



Stop-Service WSearch -Force -ErrorAction SilentlyContinue

Remove-Item "C:\ProgramData\Microsoft\Search\Data\Applications\Windows\*" `
    -Recurse -Force -ErrorAction SilentlyContinue

Start-Service WSearch -ErrorAction SilentlyContinue
Stop-Transcript