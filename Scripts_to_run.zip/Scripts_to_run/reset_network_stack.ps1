<#
🟢 6. Rebuild Network Stack (System-Only)

Fixes a ton of “no internet / weird DNS” tickets.

Fix

Reset Winsock

Reset TCP/IP

Flush DNS

Restart network services

💡 Still SYSTEM-safe: requires reboot (which you can prompt for)
#>

$LogPath = "C:\ProgramData\SelfX\Logs"
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}
Start-Transcript -Path "$LogPath\<SCRIPTNAME>.log" -Append

netsh winsock reset | Out-Null
netsh int ip reset | Out-Null
ipconfig /flushdns | Out-Null
Stop-Transcript