<#
🟢 3. Repair Windows Update Components

Slightly heavier version of #2.

Includes

Reset BITS

Re-register update DLLs

DISM health scan (optional)

💡 Good for: “Updates have been broken for months”
#>

$LogPath = "C:\ProgramData\SelfX\Logs"
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}
Start-Transcript -Path "$LogPath\<SCRIPTNAME>.log" -Append

DISM /Online /Cleanup-Image /RestoreHealth | Out-Null
sfc /scannow | Out-Null
Stop-Transcript