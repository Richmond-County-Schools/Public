$LogPath = "C:\ProgramData\SelfX\Logs"
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}
Start-Transcript -Path "$LogPath\<SCRIPTNAME>.log" -Append

Get-ScheduledTask | Where-Object {
    $_.TaskPath -like "*EnterpriseMgmt*"
} | ForEach-Object {
    Start-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath
}

Restart-Service IntuneManagementExtension -ErrorAction SilentlyContinue
Stop-Transcript