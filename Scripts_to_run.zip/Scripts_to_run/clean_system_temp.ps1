<#
🟢 10. Clear Temp & System Caches

Safe, simple, effective.

Fix

Delete:

C:\Windows\Temp

C:\ProgramData\Microsoft\Windows\WER

Optional: component cleanup via DISM

💡 Label:
“Clean System Temp Files”
#>

$LogPath = "C:\ProgramData\SelfX\Logs"
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}
Start-Transcript -Path "$LogPath\<SCRIPTNAME>.log" -Append


Remove-Item "C:\Windows\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "C:\ProgramData\Microsoft\Windows\WER\*" -Recurse -Force -ErrorAction SilentlyContinue
Stop-Transcript