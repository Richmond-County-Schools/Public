<#
🟢 8. Repair Microsoft Office (Machine-Wide)

Only if you’re using C2R / machine installs.

Fix

Trigger Office Click-to-Run repair

Restart ClickToRunSvc

💡 Good for: Office won’t launch / crashes on startup
#>