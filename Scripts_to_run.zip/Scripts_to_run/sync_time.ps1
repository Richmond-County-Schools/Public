#Requires -Version 5.1

<#
.SYNOPSIS
    Force a time synchronization with the current time settings and display the current time zone and time sync settings.
.DESCRIPTION
    Force a time synchronization with the current time settings and display the current time zone and time sync settings.
By using this script, you indicate your acceptance of the following legal terms as well as our Terms of Use at https://www.ninjaone.com/terms-of-use.
    Ownership Rights: NinjaOne owns and will continue to own all right, title, and interest in and to the script (including the copyright). NinjaOne is giving you a limited license to use the script in accordance with these legal terms. 
    Use Limitation: You may only use the script for your legitimate personal or internal business purposes, and you may not share the script with another party. 
    Republication Prohibition: Under no circumstances are you permitted to re-publish the script in any script library or website belonging to or under the control of any other software provider. 
    Warranty Disclaimer: The script is provided “as is” and “as available”, without warranty of any kind. NinjaOne makes no promise or guarantee that the script will be free from defects or that it will meet your specific needs or expectations. 
    Assumption of Risk: Your use of the script is at your own risk. You acknowledge that there are certain inherent risks in using the script, and you understand and assume each of those risks. 
    Waiver and Release: You will not hold NinjaOne responsible for any adverse or unintended consequences resulting from your use of the script, and you waive any legal or equitable rights or remedies you may have against NinjaOne relating to your use of the script. 
    EULA: If you are a NinjaOne customer, your use of the script is subject to the End User License Agreement applicable to you (EULA).

.PARAMETER -EnableAndStartWindowsTimeService
    Enable and start the Windows Time service if it is disabled or not running. This will set the Start Type to 'Automatic.' This service is required to force a time sync.

.EXAMPLE
    ### Current time zone settings: ###

    Id                         : Pacific Standard Time
    DisplayName                : (UTC-08:00) Pacific Time (US & Canada)
    StandardName               : Pacific Standard Time
    DaylightName               : Pacific Daylight Time
    BaseUtcOffset              : -08:00:00
    SupportsDaylightSavingTime : True

    ### Current time sync settings: ###

    Sync Type                      : NTP only
    NTP Servers                    : time.windows.com
    Last Sync Time                 : 5/12/2025 1:05:48 PM
    Last Sync Source               : time.windows.com
    Sync Interval (NTP)            : 10 minutes
    Sync Interval Minimum (Domain) : 1 minutes
    Sync Interval Maximum (Domain) : 546 minutes

    [Info] Attempting to force a sync with current time settings...
    Sending resync command to local computer
    The command completed successfully.

    ### Current time: ###

    Monday, May 12, 2025 1:05:55 PM

.NOTES
    Minimum OS Architecture Supported: Windows 10, Windows Server 2016
    Release Notes: Initial Release
#>

[CmdletBinding()]
param (
    [Parameter()]
    [switch]$EnableAndStartWindowsTimeService = [System.Convert]::ToBoolean($env:EnableAndStartWindowsTimeService)
)

begin {
    function Test-IsElevated {
        [CmdletBinding()]
        param ()
        
        # Get the current Windows identity of the user running the script
        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        
        # Create a WindowsPrincipal object based on the current identity
        $p = New-Object System.Security.Principal.WindowsPrincipal($id)
        
        # Check if the current user is in the Administrator role
        # The function returns $True if the user has administrative privileges, $False otherwise
        # 544 is the value for the Built In Administrators role
        # Reference: https://learn.microsoft.com/en-us/dotnet/api/system.security.principal.windowsbuiltinrole
        $p.IsInRole([System.Security.Principal.WindowsBuiltInRole]'544')
    }
    function Get-TimeSettings {
        # Get the time sync status
        try {
            $StatusOutputFilename = "$env:temp\w32tm_status_output_$(Get-Random).txt"
            Start-Process -FilePath "$env:WinDir\system32\w32tm.exe" -ArgumentList "/query /status" -RedirectStandardOutput $StatusOutputFilename -NoNewWindow -Wait
        }
        catch {
            throw (New-Object System.Exception("Unable to retrieve time sync status."))
        }
        
        # Get the time sync configuration
        try {
            $ConfigOutputFilename = "$env:temp\w32tm_config_output_$(Get-Random).txt"
            Start-Process -FilePath "$env:WinDir\system32\w32tm.exe" -ArgumentList "/query /configuration" -RedirectStandardOutput $ConfigOutputFilename -NoNewWindow -Wait
        }
        catch {
            throw (New-Object System.Exception("Unable to retrieve time sync configuration."))
        }
        
        # Attempt to read the status output file
        try {
            $status = Get-Content $StatusOutputFilename -Encoding Oem
        }
        catch {
            throw (New-Object System.Exception("Unable to read time sync status."))
        }

        # Attempt to read the config output file
        try {
            $config = Get-Content $ConfigOutputFilename -Encoding Oem
        }
        catch {
            throw (New-Object System.Exception("Unable to read time sync configuration."))
        }

        $lastSyncTime = ($status[-4] -replace "^\w+:\s" -replace "^.+: " | Out-String).Trim()
        $lastSyncSource = ($status[-3] -replace "^\w+:\s" -replace "^.+: " -replace ",0x\w" | Out-String).Trim()
        $syncType = (($config | Select-String -Pattern "^Type: ") -replace "Type: " -replace "\(.+$" | Out-String).Trim()

        $regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters"
        $NtpServers = (Get-ItemProperty -Path $regPath -Name "NtpServer" -ErrorAction SilentlyContinue).NtpServer.Trim() -replace ",0x\w" -replace "\s",", "

        $syncType = switch ($syncType) {
            "NTP" { "NTP only" }
            "NT5DS" { "Domain only" }
            "AllSync" { "Domain with NTP as fallback" }
            default { "Unknown" }
        }

        # Get the SpecialPollInterval from the config
        $SpecialPollInterval = ($config | Select-String -Pattern "^SpecialPollInterval: ") -replace "SpecialPollInterval: " -replace "\(.+$"
        # Convert the SpecialPollInterval to minutes
        $SpecialPollIntervalInMinutes = [int]$SpecialPollInterval / 60

        $object = [PSCustomObject]@{
            "Sync Type"         = $syncType
            "NTP Servers"       = $NtpServers
            "Last Sync Time"    = $lastSyncTime
            "Last Sync Source"  = $lastSyncSource
            "Sync Interval (NTP)" = "$SpecialPollIntervalInMinutes minutes"
        }

        # Get the Min and Max poll intervals used for domain time sync
        $regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config"
        $MinPollInterval = (Get-ItemProperty -Path $regPath -Name "MinPollInterval" -ErrorAction SilentlyContinue).MinPollInterval
        $MaxPollInterval = (Get-ItemProperty -Path $regPath -Name "MaxPollInterval" -ErrorAction SilentlyContinue).MaxPollInterval

        if ($MinPollInterval -and $MaxPollInterval) {
            # These values are actually powers of 2, the resulting value is the amount of seconds
            $MinPollInterval = [math]::Pow(2, $MinPollInterval)
            $MaxPollInterval = [math]::Pow(2, $MaxPollInterval)

            # Convert those seconds to minutes
            $MinPollInterval = [math]::Round($MinPollInterval / 60)
            $MaxPollInterval = [math]::Round($MaxPollInterval / 60)

            # Add the intervals to the object
            $object | Add-Member -MemberType NoteProperty -Name "Sync Interval Minimum (Domain)" -Value "$MinPollInterval minutes"
            $object | Add-Member -MemberType NoteProperty -Name "Sync Interval Maximum (Domain)" -Value "$MaxPollInterval minutes"
        }
        else {
            Write-Host -Object "[Warning] Unable to retrieve the minimum and maximum poll intervals from the registry."
            $object | Add-Member -MemberType NoteProperty -Name "Sync Interval Minimum (Domain)" -Value "Unavailable"
            $object | Add-Member -MemberType NoteProperty -Name "Sync Interval Maximum (Domain)" -Value "Unavailable"
        }

        # Attempt to remove the status output file
        try {
            Remove-Item $StatusOutputFilename -ErrorAction Stop
        }
        catch {
            Write-Host -Object "[Warning] Unable to delete the temporary file '$StatusOutputFilename'."
        }

        # Attempt to remove the config output file
        try {
            Remove-Item $ConfigOutputFilename -ErrorAction Stop
        }
        catch {
            Write-Host -Object "[Warning] Unable to delete the temporary file '$ConfigOutputFilename'."
        }

        return $object
    }
}
process {
    # Attempt to determine if the current session is running with Administrator privileges.
    try {
        $IsElevated = Test-IsElevated -ErrorAction Stop
    }
    catch {
        Write-Host -Object "[Error] $($_.Exception.Message)"
        Write-Host -Object "[Error] Unable to determine if the account '$env:Username' is running with Administrator privileges."
        exit 1
    }
    
    if (!$IsElevated) {
        Write-Host -Object "[Error] Access Denied: Please run with Administrator privileges."
        exit 1
    }

    $ExitCode = 0

    # Get status of Windows Time Service
    # This service is required for time sync
    try {
        $WindowsTimeService = Get-Service -Name "w32time" -ErrorAction Stop
    }
    catch {
        Write-Host -Object "[Error] Unable to retrieve Windows Time service status."
        Write-Host -Object "[Error] $($_.Exception.Message)"
        exit 1
    }

    # Enable the Windows Time service if requested
    if ($EnableAndStartWindowsTimeService) {
        Write-Host -Object "`n[Info] Setting Windows Time service to start up automatically..."

        # Set the start type to automatic if it is not already
        if ($WindowsTimeService.StartType -ne "Automatic") {
            try {
                Set-Service -Name "w32time" -StartupType Automatic -ErrorAction Stop
                Write-Host -Object "[Info] Windows Time service enabled successfully."
            }
            catch {
                Write-Host -Object "[Error] Unable to enable Windows Time service."
                Write-Host -Object "[Error] $($_.Exception.Message)"
                # Set flag to true so that we can skip forcing the sync
                $serviceError = $true
                $ExitCode = 1
            }
        }
        else {
            Write-Host "[Info] Windows Time service is already set to start automatically."
        }

        # Start the Windows Time service if it is not already running
        Write-Host -Object "`n[Info] Starting Windows Time service..."
        if ($WindowsTimeService.Status -ne "Running") {
            try {
                Start-Service -Name "w32time" -WarningAction SilentlyContinue -ErrorAction Stop
                Write-Host -Object "[Info] Windows Time service started successfully."
            }
            catch {
                Write-Host -Object "[Error] Unable to enable Windows Time service."
                Write-Host -Object "[Error] $($_.Exception.Message)"
                # Set flag to true so that we can skip forcing the sync
                $serviceError = $true
                $ExitCode = 1
            }
        }
        else {
            Write-Host "[Info] Windows Time service is already running."
        }
    }
    # Otherwise check if the service is running and set to start automatically, error if not
    else {
        if ($WindowsTimeService.StartType -ne "Automatic") {
            Write-Host "`n[Error] Windows Time service is not set to start automatically. Please use the 'Enable and Start Windows Time Service' option to enable it."
            # Set flag to true so that we can skip forcing the sync
            $serviceError = $true
            $ExitCode = 1
        }
        elseif ($WindowsTimeService.Status -ne "Running") {
            Write-Host "`n[Error] Windows Time service is not running. Please use the 'Enable and Start Windows Time Service' option to start it."
            # Set flag to true so that we can skip forcing the sync
            $serviceError = $true
            $ExitCode = 1
        }
    }

    # Show current time zone settings
    try {
        Write-Host -Object "`n### Current time zone settings: ###`n"
        (Get-TimeZone -ErrorAction Stop | Out-String).Trim()
    }
    catch {
        Write-Host -Object "[Error] Unable to retrieve current time zone settings."
        Write-Host -Object "[Error] $($_.Exception.Message)"
        $ExitCode = 1
    }
    
    # Show current time sync settings if the Windows Time service is running
    if (-not $serviceError) {
        try {
            Write-Host -Object "`n### Current time sync settings: ###`n"
            $timeSettings = Get-TimeSettings -ErrorAction Stop
            ($timeSettings | Format-List | Out-String).Trim()
            if ($timeSettings."Sync Type" -eq "Unknown") {
                Write-Host -Object "`n[Error] Unable to determine the sync type. The time sync settings may not be configured correctly."
                $skipSync = $true
                $ExitCode = 1
            }
        }
        catch {
            Write-Host -Object "[Error] Unable to retrieve current time sync settings."
            $skipSync = $true
            Write-Host -Object "[Error] $($_.Exception.Message)"
            $ExitCode = 1
        }
    }
    else {
        Write-Host -Object "`n[Error] Unable to retrieve current time sync settings because the Windows Time service is not running."
    }

    # Force a sync if Windows Time service is running
    if ($serviceError) {
        Write-Host "`n[Error] Unable to force a time sync because the Windows Time service is not running."
        $ExitCode = 1
    }
    elseif ($skipSync) {
        Write-Host "`n[Error] Unable to force a time sync because the sync type is unknown. Please correct the time sync settings using the 'Time Sync - Configure Settings' script in the Template Library."
    }
    else {
        try {
            Write-Host "`n[Info] Attempting to force a sync with current time settings..."

            # Create a temporary file to store the output
            $ResyncOutputFile = "$env:temp\w32tm_resync_output_$(Get-Random).txt"
            
            # Start the process to force a time sync 
            Start-Process -FilePath "$env:Windir\System32\w32tm.exe" -ArgumentList "/resync" -NoNewWindow -Wait -RedirectStandardOutput $ResyncOutputFile -ErrorAction Stop
        }
        catch {
            Write-Host -Object "[Error] Unable to initiate time sync."
            Write-Host -Object "[Error] $($_.Exception.Message)"
            $ExitCode = 1
        }

        # Make sure the output file exists
        if (Test-Path -Path $ResyncOutputFile) {
            # Read the output of the time sync
            try {
                Get-Content $ResyncOutputFile -Encoding Oem -ErrorAction Stop | Out-Host
            }
            catch {
                Write-Host -Object "[Error] Unable to read the output of the time sync."
                Write-Host -Object "[Error] $($_.Exception.Message)"
                $ExitCode = 1
            }

            # Clean up the output file
            try {
                Remove-Item -Path $ResyncOutputFile -Force -ErrorAction Stop
            }
            catch {
                Write-Host -Object "[Error] Unable to delete the output file."
                Write-Host -Object "[Error] $($_.Exception.Message)"
                $ExitCode = 1
            }
        }
        else {
            Write-Host -Object "[Error] Unable to find the output file."
            $ExitCode = 1
        }
    }
    
    # Show current time
    try {
        Write-Host -Object "`n### Current time: ###"
        Get-Date -DisplayHint DateTime -ErrorAction Stop | Out-Host
    }
    catch {
        Write-Host -Object "[Error] Unable to retrieve current time."
        Write-Host -Object "[Error] $($_.Exception.Message)"
        $ExitCode = 1
    }

    exit $ExitCode
}
end {
    
    
    
}