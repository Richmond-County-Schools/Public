<#
🟢 2. Clear Windows Update Cache

Classic. Always useful.

Fix

Stop update services

Delete:

C:\Windows\SoftwareDistribution

C:\Windows\System32\catroot2

Restart services

💡 Solves: Updates stuck at 0%, 100%, or failing repeatedly.
#>

$LogPath = "C:\ProgramData\SelfX\Logs"
if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}
Start-Transcript -Path "$LogPath\<SCRIPTNAME>.log" -Append

$services = "wuauserv","bits","cryptsvc"

foreach ($svc in $services) {
    Stop-Service $svc -Force -ErrorAction SilentlyContinue
}

Remove-Item "C:\Windows\SoftwareDistribution" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "C:\Windows\System32\catroot2" -Recurse -Force -ErrorAction SilentlyContinue

foreach ($svc in $services) {
    Start-Service $svc -ErrorAction SilentlyContinue
}

Stop-Transcript