<#
🟢 11. Re-register Windows Apps (Machine Scope Only)

Careful — but useful.

Fix

Re-register machine-wide AppX packages

💡 Solves: Start menu or Settings acting weird
⚠️ Avoid per-user app repair
#>