param (
    [Parameter(Mandatory = $true)]    
    [string]$scriptName
)

Add-Type -AssemblyName PresentationFramework

$staticPassword = "RCSAdmin2026"
$maxAttempts = 5
$attempt = 0

while ($attempt -lt $maxAttempts) {

    $remaining = $maxAttempts - $attempt

    [xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Authorization Required"
        Height="200"
        Width="400"
        WindowStartupLocation="CenterScreen"
        ResizeMode="NoResize"
        Topmost="True">
    <Grid Margin="15">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <TextBlock Grid.Row="0"
                   Text="Enter password to continue"
                   Margin="0,0,0,10"
                   FontSize="14"/>

        <PasswordBox Grid.Row="1" Name="PasswordBox" Height="28"/>

        <StackPanel Grid.Row="2"
                    Orientation="Horizontal"
                    HorizontalAlignment="Right"
                    Margin="0,15,0,0">
            <Button Name="OkBtn" Width="75" Margin="0,0,10,0">OK</Button>
            <Button Name="CancelBtn" Width="75">Cancel</Button>
        </StackPanel>
    </Grid>
</Window>
"@

    $reader = New-Object System.Xml.XmlNodeReader $xaml
    $window = [Windows.Markup.XamlReader]::Load($reader)

    $PasswordBox = $window.FindName("PasswordBox")
    $OkBtn = $window.FindName("OkBtn")
    $CancelBtn = $window.FindName("CancelBtn")

    $script:EnteredPassword = $null
    $script:Cancelled = $false

    $OkBtn.Add_Click({
        $script:EnteredPassword = $PasswordBox.Password
        $window.Close()
    })

    $CancelBtn.Add_Click({
        $script:Cancelled = $true
        $window.Close()
    })

    $window.ShowDialog() | Out-Null

    # ---- Cancel ----
    if ($Cancelled) {
        exit 10
    }

    # ---- Check password ----
    if ($EnteredPassword -eq $staticPassword) {
        # Create txt file in current directory to indicate successful authentication
        $currentFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
        $authFilePath = Join-Path -Path $currentFolder -ChildPath "success.txt"
        New-Item -Path $authFilePath -ItemType File -Force | Out-Null
        & "$currentFolder\ServiceUI.exe" `
        -process:explorer.exe `
        "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" `
        -NoProfile `
        -ExecutionPolicy Bypass `
        -WindowStyle Hidden `
        -File "$currentFolder\$scriptName.ps1"
        exit 0
    }

    # ---- Failed attempt ----
    $attempt = 0
    $attempt++

    if ($attempt -lt $maxAttempts) {
        $owner = New-Object System.Windows.Window
        $owner.WindowStyle = 'None'
        $owner.ShowInTaskbar = $false
        $owner.Topmost = $true
        $owner.Width = 1
        $owner.Height = 1
        $owner.Left = -1000
        $owner.Top = -1000

        $owner.Show()

        [System.Windows.MessageBox]::Show(
            $owner,
            "Incorrect password.`n`nAttempt $attempt of 5",
            "Access Denied",
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Warning
        )

        $owner.Close()

    }
}

# ---- Too many attempts ----
[System.Windows.MessageBox]::Show(
    "Too many incorrect attempts. This action has been cancelled.",
    "Access Denied",
    "OK",
    "Error"
)

exit 20
