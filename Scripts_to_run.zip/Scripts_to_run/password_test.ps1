Add-Type -AssemblyName PresentationFramework

# Create a hidden TopMost owner window
$owner = New-Object System.Windows.Window
$owner.WindowStyle = 'None'
$owner.ShowInTaskbar = $false
$owner.Topmost = $true
$owner.Width = 1
$owner.Height = 1
$owner.Left = -1000
$owner.Top = -1000
$owner.Show()

# Show the message box with the hidden owner
[System.Windows.MessageBox]::Show(
    $owner,
    "The script has executed successfully.",
    "Script Execution Successful",
    [System.Windows.MessageBoxButton]::OK,
    [System.Windows.MessageBoxImage]::Information
)

# Close the hidden owner window
$owner.Close()
